<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class CategoryRepository extends Model
{
    protected $table = 'categorias';
}
