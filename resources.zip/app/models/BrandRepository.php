<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class BrandRepository extends Model
{
    protected $table = 'marcas';
}
