<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductVenta extends Model
{
    protected $table = 'producto_ventas';
}
