<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class APIVentasController extends Controller
{
    //
}
