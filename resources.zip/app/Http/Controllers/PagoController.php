<?php

namespace App\Http\Controllers;

use App\models\PagoRepository;
use Illuminate\Http\Request;

class PagoController extends Controller{



}
