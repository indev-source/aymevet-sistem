<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <?php if($traspaso->estatus == 'autorizado'): ?>
            <div class="alert alert-success">
                <strong>Este traspasos ya fue autorizado</strong>
            </div>
        <?php endif; ?>
        <?php if(session('status_success')): ?>
            <div class="alert alert-success">
                <?php echo session('status_success'); ?>

            </div>
        <?php endif; ?>
        <?php if(session('status_warning')): ?>
            <div class="alert alert-warning">
                <?php echo session('status_warning'); ?>

            </div>
        <?php endif; ?>
        <?php if(Auth::user()->bussine_id == $traspaso->envia and $traspaso->estatus == 'enviado'): ?>
            <div class="alert alert-warning">Traspasos <span class="<?php echo e($traspaso->estatus); ?>"><?php echo e($traspaso->estatus); ?></span>, esperando a que la sucursal <?php echo e($traspaso->srecibe->nombre); ?> reciba los productos</div>
        <?php endif; ?>
    </div>
	<div class="col-md-12">
		<div class="card">
			<div class="content">
                <ul class="list-group">
                    <li class="list-group-item">
                        <strong>Envia: </strong><?php echo e($traspaso->senvia->nombre); ?>

                    </li>
                    <li class="list-group-item">
                        <strong>Recibe: </strong><?php echo e($traspaso->srecibe->nombre); ?>

                    </li>
                    <li class="list-group-item">
                        <strong>Usuario: </strong><?php echo e($traspaso->usuario->name); ?>

                    </li>
                    <li class="list-group-item">
                        <strong>Fecha: </strong><?php echo e($traspaso->created_at); ?>

                    </li>
                </ul>
                <!--AUTORIZAR TRASPASO SOLO SI ERES ADMINISTRADOR-->
                <?php if(Auth::user()->rol == 'administrador' and $traspaso->estatus == 'aceptado' and $traspaso->envia == Auth::user()->bussine_id): ?>
                    <form action="<?php echo e(asset('dashboard/v/admin/autorizar/traspaso/'.$traspaso->id)); ?>" method="post" class="text-center">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('put')); ?>

                        <button type="submit" class="btn btn-danger">Autorizar</button>
                    </form>
                <?php endif; ?>
                <!--ACEPTAR TRASPASO SOLO SI ERES ADMINISTRADOR-->
                <?php if(Auth::user()->rol == 'administrador' and $traspaso->estatus == 'enviado' and $traspaso->recibe == Auth::user()->bussine_id): ?>
                    <form action="<?php echo e(asset('dashboard/aceptar/traspaso/'.$traspaso->id)); ?>" method="post"  class="text-center">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('put')); ?>

                        <button type="submit" class="btn btn-danger">Aceptar traspaso de productos</button>
                    </form>
                <?php endif; ?>
			</div>
		</div>
	</div>
	<div class="col-md-12">
		<div class="card">
			<div class="header">
				<h4 class="title">Detalle de traspaso</h4>
				<a href="<?php echo e(asset('dashboard/v/admin/reporte/traspaso/'.$traspaso->id)); ?>" class="btn btn-xs btn-info">Imprimir hoja  de reporte</a>  Productos en el traspaso
			</div><hr>
			<div class="content">
				<div class="table-responsive">
					<table class="table table-striped">
						<thead>
							<th class="text-center">Producto</th>
							<th class="text-center">Cantidad</th>
							<th class="text-center">Costo</th>
							<th class="text-center">Venta</th>
							<th class="text-center">Clave producto</th>
							<th class="text-center">Codigo</th>
							<th class="text-center">Codigo unidad</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td class="text-center"><?php echo e($product->product->nombre); ?></td>
									<td class="text-center"><?php echo e($product->cantidad); ?></td>
									<td class="text-center">$<?php echo e($product->product->costo); ?></td>
									<td class="text-center">$<?php echo e($product->product->precio1); ?></td>
									<td class="text-center"><?php echo e($product->product->clave_producto); ?></td>
									<td class="text-center"></td>
									<td class="text-center"><?php echo e($product->product->clave_unidad); ?></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>