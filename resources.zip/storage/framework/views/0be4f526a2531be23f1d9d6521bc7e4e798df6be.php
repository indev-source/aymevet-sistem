<table  id="data" class="table table-striped table-bordered">
	<thead>
		<th class="text-center">Nombre</th>
		<th class="text-center">Acciones</th>
	</thead>
	<tbody>
		<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td class="text-center">
                   <?php echo e($brand->nombre); ?>

                </td>
				<td class="text-center">
                	<a href="<?php echo e(asset(Auth::user()->rol == 'administrador' ? 'administrador/marcas/'.$brand->id.'/edit' : '#')); ?>" class="btn btn-primary btn-sm"><span class="fa fa-edit"></span> Actualizar</a>
					<a href="<?php echo e(asset('productos-marca?marca='.$brand->id)); ?>" class="btn btn-info btn-sm"> <span class="fa fa-shopping-basket"></span> Productos</a>
				</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<div class="content">
	
</div>