<?php $__env->startSection('title','Agregar categoria'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
	<a href="<?php echo e(asset('dashboard/v/admin/categorias/')); ?>" class="float">
		<i class="fa fa-undo  my-float"></i>
	</a>
	<div class="card">
		<div class="header">
			<h4 class="title">Edita la categoria <?php echo e($category->nombre); ?></h4>
		</div> <hr>
		<div class="content content-form table-responsive table-full-width">
			<form action="<?php echo e(asset('dashboard/v/admin/categorias/'.$category->id)); ?>" method="post">
				<?php echo csrf_field(); ?>
				<?php echo e(method_field('put')); ?>

				<div class="row">
					<div class="col-md-12">
						<label for="">Nombre </label>
						<input type="text" required  class="form-control <?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" name="nombre" placeholder="Ingresa el nombre de la categoria" value="<?php echo e($category->nombre); ?>">
						<?php if($errors->has('nombre')): ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($errors->first('nombre')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="row">
					<div class="form-group">
						<button type="submit" class="btn btn-success margin-top margen-izquierda">Actualizar Categoria</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>