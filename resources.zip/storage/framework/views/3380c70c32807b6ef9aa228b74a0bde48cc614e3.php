<?php $__env->startSection('title','Servicios'); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status_success')): ?>
<div class="alert alert-success">
	<?php echo session('status_success'); ?>

</div>
<?php endif; ?>
<div class="col-md-12">
	<?php echo $__env->make('sales.data-products', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<div class="col-md-12">
	<div class="card">
		<div class="header" style="display: flex; align-items: center; justify-content: space-between;">
			<h3 class="title">Detalle del servicio, FOLIO: <?php echo e($servicio->id); ?>, FECHA: <?php echo e($sale->date); ?></h3>
			<a href="<?php echo e(asset('reportes/servicios/'.$servicio->id)); ?>" class="btn btn-success btn-sm">Exportar PDF</a>
		</div><hr>
		<div class="content">
			<div class="form-group">
				<label for="">Nombre del cliente</label>
				<input required="Ingresa el campo" disabled="" value="<?php echo e($servicio->nombre_cliente); ?>" type="text" name="nombre_cliente" class="form-control">
			</div>
			<div class="form-group">
				<label for="">Dirección</label>
				<input required="Ingresa el campo" value="<?php echo e($servicio->direccion); ?>" disabled="" type="text" name="direccion" class="form-control">
			</div>
			<div class="form-group">
				<label for="">Teléfono</label>
				<input required="Ingresa el campo " value="<?php echo e($servicio->telefono); ?>" disabled="" type="text" name="telefono" class="form-control">
			</div>
			<div class="form-group">
				<label for="">Modelo de la italika</label>
				<input required="Ingresa el campo " type="text" value="<?php echo e($servicio->modelo_italika); ?>" disabled="" name="modelo_italika" class="form-control">
			</div>
			<div class="form-group">
				<label for="">Numero de serie</label>
				<input required="Ingresa el campo " type="text" value="<?php echo e($servicio->numero_serie); ?>" disabled="" name="numero_serie" class="form-control">
			</div>
			<div class="form-group">
				<label for="">Cuenta con garantía activa</label>
				<select required="Ingresa el campo " disabled="" name="garantia" class="form-control" id="">
					<option><?php echo e($servicio->garantia); ?></option>
					
				</select>
			</div>
			<div class="form-group">
				<label for="">Kilometraje</label>
				<input required="Ingresa el campo " value="<?php echo e($servicio->kilometraje); ?>" disabled="" type="text" name="kilometraje" class="form-control">
			</div>
			<div class="form-group">
				<label for="">Orden del servicio</label>
				<input required="Ingresa el campo " value="<?php echo e($servicio->orden_servicio); ?>" disabled="" type="text" name="orden_servicio" class="form-control">
			</div>
			<div class="form-group">
				<label for="">Tipo de servicios</label>
				<select required="Ingresa el campo "  disabled="" class="form-control" name="tipo_servicio" id="">
					<option value=""><?php echo e($servicio->numero_serie); ?></option>
				</select>
			</div>
			<div class="form-group">
				<label for="">Comentarios del cliente</label>
				<textarea required="Ingresa el campo " disabled=""  name="comentarios" class="form-control" id="" cols="30" rows="10"><?php echo e($servicio->comentarios); ?>

				</textarea>
			</div>
			<div class="form-group">
				<label for="">Sin daños</label>
				<select required="Ingresa el campo" disabled="" name="sin_danios" class="form-control" id="">
					<option value="si"><?php echo e($servicio->sin_danios); ?></option>
					
				</select>
			</div>
			<div class="form-group">
				<label for="">Sin odómetro</label>
				<select name="sin_odometraje" disabled="" class="form-control" id="">
					<option value="<?php echo e($servicio->sin_odometraje); ?>"><?php echo e($servicio->sin_odometraje); ?></option>
					
				</select>
			</div>

			<div class="form-group">
				<label for="">Precio de mano de obra</label>
				<input required="Ingresa el campo " value="$<?php echo e(number_format($servicio->precio_mano_obre,2,'.',',')); ?>" disabled="" type="text" name="precio_mano_obre" class="form-control">
			</div>

			<div class="form-group">
				<label for="">Precio de los consumibles(Venta)</label>
				<input required="Ingresa el campo " value="$<?php echo e(number_format($servicio->precio_consumible,2,'.',',')); ?>" disabled="" type="text" name="precio_consumible" class="form-control">
			</div>

			<div class="form-group">
				<label for="">Total</label>
				<input required="Ingresa el campo " value="$<?php echo e(number_format($servicio->total,2,'.',',')); ?>" type="text" disabled="" name="total" class="form-control">
			</div>

			<div class="form-group">
				<label for="">Fecha de entrega</label>
				<input required="Ingresa el campo " value="<?php echo e($servicio->fecha_entrega); ?>" disabled="" type="date" name="fecha_entrega" class="form-control">
			</div>

			<div class="form-group">
				<label for="">Telefono del CESIT</label>
				<input required="Ingresa el campo " value="<?php echo e($servicio->telefono_cecit); ?>" disabled="" type="text" name="telefono_cecit" class="form-control">
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>