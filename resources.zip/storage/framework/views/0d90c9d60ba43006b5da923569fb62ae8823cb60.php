<table class="table table-striped">
	<thead>
		<th class="text-center">ID</th>
		<th class="text-center">Nombre</th>
		<th class="text-center">Codigo</th>
		<th class="text-center">Clave unidad</th>
		<th class="text-center">Clave Producto</th>
		<th class="text-center">Existencia</th>
		<th class="text-center">Costo</th>
		<th class="text-center">Venta</th>
		<th class="text-center">Categoria</th>
		<th class="text-center">Sucursal</th>
	</thead>
	<tbody>
		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td class="text-center"><?php echo e($product->id); ?></td>
				<td class="text-center">
					<a href="<?php echo e(asset('dashboard/v/admin/productos/'.$product->id.'/edit')); ?>"><?php echo e($product->producto); ?></a>
				</td>
				<td class="text-center"><?php echo e($product->codigo); ?></td>
				<td class="text-center"><?php echo e($product->clave_unidad); ?></td>
				<td class="text-center"><?php echo e($product->clave_producto); ?></td>
				<td class="text-center">
					<?php if($product->stock >5): ?>
					<span class="label label-success"><?php echo e($product->stock); ?></span>
					<?php else: ?>
					<span class="label label-danger"><?php echo e($product->stock); ?></span>
					<?php endif; ?>
				</td>
				<td class="text-center">$<?php echo e(number_format($product->costo)); ?></td>
				<td class="text-center">$<?php echo e(number_format($product->venta)); ?></td>
				<td class="text-center"><?php echo e($product->categoria); ?></td>
				<td class="text-center"><?php echo e($product->sucursal); ?></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<div class="content">
	<?php echo e($products->links()); ?>

</div>