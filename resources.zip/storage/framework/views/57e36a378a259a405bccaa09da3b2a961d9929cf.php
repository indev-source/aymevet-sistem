<?php $__env->startSection('title','Listado de productos por categoria'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
	<?php if(session('status_success')): ?>
        <div class="alert alert-success">
            <?php echo session('status_success'); ?>

        </div>
    <?php endif; ?>
	 <div class="card">
    	<div class="content">
    		<?php echo $__env->make('products.filter', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    	</div>
    </div>
	<div class="card">
		<div class="header">
			<h4 class="title">Listado de productos de la categoria <a href="#"><?php echo e($category->nombre); ?></a>.</h4>
			<p class="category">Listado de todos los productos activos.</p>
		</div>
		<div class="content table-responsive">
			<?php echo $__env->make('products.data', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
	<script>
		function SearchByCategories($category_id){
			let server = "http://localhost:8000/dashboard/v/admin/";
			let route  = server+"producto?categoria="+$category_id;
			location.href= route;
		}
		function allCategories(){
			let server = "http://localhost:8000/dashboard/v/admin/";
			let route  = "productos";
			location.href= route;
		}
		function allBussines(){
			let server = "http://localhost:8000/dashboard/v/admin/";
			let route  = "productos";
			location.href= route;
		}
		function searchByBussines($bussine_id){
			let server = "http://localhost:8000/dashboard/v/admin/";
			let route  = server+"producto_?sucursal="+$bussine_id;
			location.href= route;
		}
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>