<?php $__env->startSection('title','Empleados'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <?php if(session('status_success')): ?>
            <div class="alert alert-success">
                <?php echo session('status_success'); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <div class="header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap;">
                <h4 class="title">Selecciona tus productos de la compra.</h4>
            </div>
            <div class="content table-responsive">
                <div class="row">
                    <div class="col-md-9">
                        <table id="data" class="table table-bordered">
                            <thead>
                            <tr>
                                <th class="text-center">Producto</th>
                                <th class="text-center">Costo</th>
                                <th class="text-center">Stock</th>
                                <th class="text-center">Cantidad</th>
                                <th class="text-center">Accion</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($product->nombre); ?></td>
                                    <td class="text-center">$<?php echo e(number_format($product->costo,2,'.',',')); ?></td>
                                    <td class="text-center">
                                        <?php echo e($product->existencia); ?>

                                    </td>
                                    <form action="<?php echo e(asset('administrador/producto-compras')); ?>" method="post">
                                        <input type="hidden" name="producto_id" value="<?php echo e($product->id); ?>">
                                        <input type="hidden" name="compra_id" value="<?php echo e($compra->id); ?>">
                                        <?php echo csrf_field(); ?>
                                        <td class="text-center">
                                            <input type="number" required class="form-control" name="cantidad">
                                        </td>
                                        <td class="text-center">
                                            <button class="btn btn-success btn-xs" type="submit">Agregar</button>
                                        </td>
                                    </form>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-3 text-center">
                        <h5 class="title">Productos agregados</h5>
                        <form action="<?php echo e(asset('administrador/producto-compras/'.$compra->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('put')); ?>

                            <button type="submit" class="btn btn-success btn-xs">Terminar compra</button>
                        </form>
                        <hr>
                        <ul class="list-group" style="height: 300px; overflow-y: scroll;">
                            <?php $__currentLoopData = $productsCompra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCompra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item">
                                    <?php echo e($productCompra->product->nombre); ?> <br>
                                    Cantidad: <?php echo e($productCompra->cantidad); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>