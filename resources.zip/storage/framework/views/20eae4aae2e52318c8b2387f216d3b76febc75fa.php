<?php if(session('status_warning')): ?>
    <div class="alert alert-danger">
        <strong class="text-uppercase color-white"><?php echo session('status_warning'); ?></strong>
    </div>
<?php endif; ?>