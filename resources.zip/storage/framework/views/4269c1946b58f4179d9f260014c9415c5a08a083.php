<?php $__env->startSection('title','Empleados'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <?php if(session('status_success')): ?>
            <div class="alert alert-success">
                <?php echo session('status_success'); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <div class="header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap;">
                <h4 class="title">Agregar nueva compra</h4>
            </div>
            <div class="content">
                <form action="<?php echo e(asset('administrador/compras')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Total: </label>
                        <input type="number" class="form-control" step="any" name="total" required>
                    </div>
                    <div class="form-group">
                        <label for="">Fecha de compro: </label>
                        <input required type="date" class="form-control" name="fecha">
                    </div>
                    <div class="form-group">
                        <label for="">Tipo de compra: </label>
                        <select class="form-control" name="tipo_compra" required id="">
                            <option value="">Selecciona una opción</option>
                            <option onclick="contado();" value="contado">Contado</option>
                            <option onclick="credito();" value="credito">Credito</option>
                        </select>
                    </div>
                    <div class="form-group desactivate" id="credito-compra">
                        <label for="">Fecha de pago: </label>
                        <input type="date" class="form-control" name="fecha_pago">
                    </div>
                    <button class="btn btn-success" type="submit">Seleccionar productos</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script>
    function credito(){
        let credito_compra  = document.querySelector("#credito-compra");
        console.log(credito_compra)
        credito_compra.classList.remove('desactivate');
    }
    function contado(){
        let credito_compra  = document.querySelector("#credito-compra");
        console.log(credito_compra)
        credito_compra.classList.add('desactivate');
    }
</script>

<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>