<?php $__env->startSection('title','Agregar sucursal'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
	<a href="<?php echo e(asset('dashboard/v/admin/sucursales/')); ?>" class="float">
		<i class="fa fa-undo  my-float"></i>
	</a>
	<div class="card">
		<div class="header">
			<h4 class="title">Agrega una nueva sucursal al sistema</h4>
		</div> <hr>
		<div class="content content-form table-responsive table-full-width">
			<form action="<?php echo e(asset('dashboard/v/admin/sucursales/')); ?>" method="post">
				<?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-md-6">
						<label for="">Nombre de la sucursal</label>
						<input type="text" required  class="form-control <?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" name="nombre" placeholder="Ingresa el nombre de la sucursal" value="<?php echo e(old('name')); ?>">
						<?php if($errors->has('nombre')): ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($errors->first('nombre')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
					<div class="col-md-6">
						<label for="">Calle</label>
						<input type="text" required  class="form-control <?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" name="calle" placeholder="Ingresa la calle de la sucursal" value="<?php echo e(old('calle')); ?>">
						<?php if($errors->has('nombre')): ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($errors->first('nombre')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<label for="">Colonia de la sucursal</label>
						<input type="text" required  class="form-control <?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" name="colonia" placeholder="Ingresa la colonia de la sucursal" value="<?php echo e(old('name')); ?>">
						<?php if($errors->has('nombre')): ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($errors->first('nombre')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
					<div class="col-md-6">
						<label for="">Estado de la sucursal</label>
						<input type="text" required  class="form-control <?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" name="estado" placeholder="Ingresa el estado de la sucursal" value="<?php echo e(old('calle')); ?>">
						<?php if($errors->has('nombre')): ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($errors->first('nombre')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<label for="">Ciudad de la sucursal</label>
						<input type="text" required  class="form-control <?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" name="ciudad" placeholder="Ingresa la ciudad de la sucursal" value="<?php echo e(old('name')); ?>">
						<?php if($errors->has('nombre')): ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($errors->first('nombre')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
					<div class="col-md-6">
						<label for="">Pais de la sucursal</label>
						<input type="text" required  class="form-control <?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" name="pais" placeholder="Ingresa el Pais de la sucursal" value="<?php echo e(old('calle')); ?>">
						<?php if($errors->has('nombre')): ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($errors->first('nombre')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<label for="">Numero exterior de la sucursal</label>
						<input type="number" required  class="form-control <?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" name="exterior" placeholder="Ingresa el numero exterior de la sucursal" value="<?php echo e(old('name')); ?>">
						<?php if($errors->has('nombre')): ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($errors->first('nombre')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
					<div class="col-md-6">
						<label for="">Numero Interior de la sucursal</label>
						<input type="text" required  class="form-control <?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" name="interior" placeholder="Ingresa el estado de la sucursal" value="0">
						<?php if($errors->has('nombre')): ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($errors->first('nombre')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<label for="">Porcentaje de P/tarjeta de la sucursal</label>
						<input type="text" required  class="form-control <?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" name="tarjeta" placeholder="Ingresa el porcentaje con P/tarjeta
						 de la sucursal" value="<?php echo e(old('calle')); ?>">
						<?php if($errors->has('nombre')): ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($errors->first('nombre')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="row">
					<div class="form-group">
						<button type="submit" class="btn btn-success margin-top margen-izquierda">Agregar Categoria</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>