<table id="data" class="table table-striped table-bordered">
    <thead>
        <th class="text-center">FOL</th>
        <th class="text-center">Total</th>
        <th class="text-center">Vendedor</th>
        <th class="text-center">Cliente</th>
        <th class="text-center">Ruta</th>
        <th class="text-center">Fecha</th>
        <th class="text-center">Estatus</th>
        <th class="text-center">

        </th>
    </thead>
    <tbody>
    <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($sale->id); ?></td>
            <td class="text-center">$<?php echo e(number_format($sale->total,2,'.',',')); ?></td>
            <td class="text-center"><?php echo e($sale->seller->name); ?></td>
            <td class="text-center"><?php echo e($sale->customer->nombre_completo); ?></td>
            <td class="text-center"><?php echo e($sale->business->nombre); ?></td>
            <td class="text-center"><?php echo e($sale->fecha); ?></td>
            <td class="text-center"><?php echo e($sale->estatus); ?></td>
            <td class="text-center">
                <a href="<?php echo e(asset(Auth::user()->rol.'/ventas/'.$sale->id)); ?>" class="btn btn-success btn-sm">Detalle</a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
