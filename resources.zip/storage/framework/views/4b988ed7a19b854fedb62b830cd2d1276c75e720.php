<table  id="data" class="table table-striped table-bordered">
	<thead>
		<th class="text-center">Nombre</th>
		<th class="text-center">Stock</th>
		<th class="text-center">Costo</th>
		<th class="text-center">Categoria</th>
		<th class="text-center">Marca</th>
		<th class="text-center">Proveedor</th>
		<th class="text-center">Sucursal</th>
	</thead>
	<tbody>
		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td class="text-center">
					<?php if(Auth::user()->rol == 'administrador'): ?>
						<a href="<?php echo e(asset(Auth::user()->rol.'/productos/'.$product->id.'/edit')); ?>"><?php echo e($product->nombre); ?></a>
					<?php else: ?>
						<?php echo e($product->nombre); ?>

					<?php endif; ?>
				</td>
				<td class="text-center">
					<?php if($product->stock >5): ?>
					<span class="label label-success"><?php echo e($product->stock); ?></span>
					<?php else: ?>
					<span class="label label-danger"><?php echo e($product->stock); ?></span>
					<?php endif; ?>
				</td>
				<td class="text-center">$<?php echo e(number_format($product->costo,2,'.',',')); ?></td>
				<td class="text-center"><?php echo e($product->categoria); ?></td>
				<td class="text-center"><?php echo e($product->marca); ?></td>
				<td class="text-center"><?php echo e($product->proveedor); ?></td>
				<td class="text-center"><?php echo e($product->bussine); ?></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<div class="content">
	
</div>
