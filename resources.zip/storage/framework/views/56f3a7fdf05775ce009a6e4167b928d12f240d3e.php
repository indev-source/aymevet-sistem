<?php $__env->startSection('title','Clientes'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
	<?php if(session('status_success')): ?>
        <div class="alert alert-success">
            <?php echo session('status_success'); ?>

        </div>
    <?php endif; ?>
	<div class="card">
		<div class="header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap;">
			<h4 class="title">Listado de clientes.</h4>
			<p class="category">
				<?php if(Auth::user()->rol == 'administrador'): ?>
					<a class="btn btn-success btn-sm" href="<?php echo e(asset(Auth::user()->rol.'/clientes/create')); ?>">Agregar cliente</a>
				<?php endif; ?>
			</p>
		</div>
		<div class="content table-responsive ">
			<?php echo $__env->make('clientes.data', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>