<?php $__env->startSection('title','Listado de usuarios'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
	<a href="<?php echo e(asset('dashboard/v/admin/usuarios/')); ?>" class="float">
		<i class="fa fa-undo  my-float"></i>
	</a>
	<div class="card">
		<div class="header">
			<h4 class="title">Agrega un nuevo usuario al sistema</h4>
		</div> <hr>
		<div class="content content-form table-responsive table-full-width">
			<form action="<?php echo e(asset('dashboard/v/admin/usuarios')); ?>" method="post">
				<?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-md-6">
						<label for="">Nombre completo</label>
						<input type="text" required  class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="name" placeholder="Ingresa el nombre completo del usuario" value="<?php echo e(old('name')); ?>">
						<?php if($errors->has('name')): ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($errors->first('name')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
					<div class="col-md-6">
						<label for="">Celular</label>
						<input type="text" required class="form-control" name="celular" placeholder="Ingresa el celular del usuario">
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<label for="">Email</label>
						<input type="email" required class="form-control" name="email" placeholder="Ingresa el email del usuario">
					</div>
					<div class="col-md-6">
						<label for="">Password</label>
						<input type="password" required class="form-control" name="password" placeholder="Ingresa la contraseña del usuario">
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<label for="">Rol</label>
						<select name="rol" required class="form-control" name="rol" id="">
							<option value="" selected="">Selecciona el rol del usuario</option>
							<option value="administrador">Administrador</option>
							<option value="vendedor">Vendedor</option>
						</select>
					</div>
					<div class="col-md-6">
						<label for="">Sucursal</label>
						<select name="bussine_id" required class="form-control" name="rol" id="">
							<option value="" selected="">Selecciona la sucursal del usuario</option>
							<?php $__currentLoopData = $bussines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bussine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($bussine->id); ?>"><?php echo e($bussine->nombre); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<label for="">Comision de usuario por ventas</label>
						<input type="number" required class="form-control"  name="comision" step="any"  placeholder="Ingresa el email del usuario">
					</div>
				</div>
				<div class="row">
					<div class="form-group">
						<button type="submit" class="btn btn-success margin-top margen-izquierda">Agregar Usuario</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>