<?php $__env->startSection('title','Ventas'); ?>
<?php $__env->startSection('content'); ?>
<?php if(isset($ganancias)): ?>
<div class="row">
	<div class="col-lg-3 col-sm-6">
		<div class="card">
			<div class="content">
				<div class="row">
					<div class="col-xs-5">
						<div class="icon-big icon-warning text-center">
							<i class="ti-money"></i>
						</div>
					</div>
					<div class="col-xs-7">
						<div class="numbers">
							<p>Ganancias</p>
							$<?php echo e($ganancias); ?>

						</div>
					</div>
				</div>
				<div class="footer">
					<hr />
					<div class="stats">
						<i class="ti-reload"></i> Todas las ventas.
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-lg-3 col-sm-6">
		<div class="card">
			<div class="content">
				<div class="row">
					<div class="col-xs-5">
						<div class="icon-big icon-success text-center">
							<i class="ti-bar-chart"></i>
						</div>
					</div>
					<div class="col-xs-7">
						<div class="numbers">
							<p>Ventas</p>
							<?php echo e($count); ?>

						</div>
					</div>
				</div>
				<div class="footer">
					<hr />
					<div class="stats">
						<a href=""><i class="ti-calendar"></i> Ver grafica de ventas.</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-lg-3 col-sm-6">
		<div class="card">
			<div class="content">
				<div class="row">
					<div class="col-xs-5">
						<div class="icon-big icon-danger text-center">
							<i class="ti-money"></i>
						</div>
					</div>
					<div class="col-xs-7">
						<div class="numbers">
							<p>Invertido</p>
							<span style="font-size: 16px;">$<?php echo e($invertedMoney); ?></span>
						</div>
					</div>
				</div>
				<div class="footer">
					<hr />
					<div class="stats">
						<i class="ti-timer"></i> MXN
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-lg-3 col-sm-6">
		<div class="card">
			<div class="content">
				<div class="row">
					<div class="col-xs-5">
						<div class="icon-big icon-info text-center">
							<i class="ti-timer"></i>
						</div>
					</div>
					<div class="col-xs-7">
						<div class="numbers">
							<p>Reportes</p>
							+45
						</div>
					</div>
				</div>
				<div class="footer">
					<hr />
					<div class="stats">
						<i class="ti-reload"></i> Updated now
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php endif; ?>
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="header">
				<h4 class="title">Buscar ventas entre fechas.</h4>
				
			</div>
			<div class="content">
				<div class="row">
					<div class="col-md-7">
						<div class="row">
							<form action="<?php echo e(asset('dashboard/v/admin/filtro')); ?>" style="margin-top: -8px;" method="get">
								<div class="col-md-4">
									<input type="date" required name="date_start" class="form-control" style="background-color: #ffff; border:solid 1px #66615B; color:#333;">
								</div>
								<div class="col-md-4">
									<input type="date" required name="date_end" class="form-control" style="background-color: #ffff; border:solid 1px #66615B; color:#333;">
								</div>
								<div class="col-md-4">
									<button type="submit" class="btn btn-success">Filtrar entre fechas</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="card">
			<div class="header">
				<h4 class="title">
					Listado de las ventas pagadas
					<?php if(isset($reporte_fechas)): ?>
						del dia <?php echo e($fecha1); ?> al <?php echo e($fecha2); ?>

					<?php endif; ?>
				</h4>
				<p class="category">Ventas pagadas.</p>
			</div>
			<div class="content table-responsive ">
				
				<table id="data" class="table table-striped table-bordered">
					<thead>
						<th class="text-center">FOLIO</th>
						<th class="text-center">Total</th>
						<th class="text-center">Vendedor</th>
						<th class="text-center">Sucursal</th>
						<th class="text-center">Tipo pago</th>
						<th class="text-center">Cliente</th>
						<th class="text-center">Fecha</th>
						<th class="text-center">Estatus</th>
					</thead>
					<tbody>
						<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td class="text-center">
									<a href="<?php echo e(asset('dashboard/v/admin/ventas/'.$sale->ventaID)); ?>"><?php echo e($sale->ventaID); ?></a>
								</td>
								<td class="text-center">$<?php echo e(number_format($sale->total)); ?></td>
								<td class="text-center">
									<?php echo e($sale->vendedor); ?>

								</td>
								<td class="text-center">
									<?php echo e($sale->bussine); ?>

								</td>
								<td class="text-center">
									<?php echo e($sale->tipo_pago); ?>

								</td>
								<td class="text-center">
									<?php echo e($sale->cliente); ?>

								</td>
								<td class="text-center"><?php echo e($sale->date); ?></td>
								<td class="text-center">
									<span class="label <?php echo e($sale->status); ?>"><?php echo e($sale->status); ?></span>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
					</tbody>
				</table>
				<div class="content">
					
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>