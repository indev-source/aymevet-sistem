
<?php $__env->startSection('title','Sucursales'); ?>
<?php $__env->startSection('content'); ?>

<div class="col-md-12">
	<?php if(session('status_success')): ?>
        <div class="alert alert-success">
            <?php echo session('status_success'); ?>

        </div>
    <?php endif; ?>
	<div class="card">
		<div class="header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap;">
			<h4 class="title">Listado de sucursales.</h4>
			<p class="category">
				<a class="btn btn-success btn-sm" href="<?php echo e(asset(Auth::user()->rol.'/sucursales/create')); ?>" >
					Agregar sucursal
				</a>
			</p>
		</div>
		<div class="content table-responsive ">
			<table id="data" class="table table-striped table-bordered">
				<thead>
					<th class="text-center">Nombre</th>
					<th class="text-center">Tarjeta</th>
					<th class="text-center">Estatus</th>
				</thead>
				<tbody>
					<?php $__currentLoopData = $bussines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bussine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td class="text-center">
								<a href="<?php echo e(asset(Auth::user()->rol.'/sucursales/'.$bussine->id.'/edit')); ?>"><?php echo e($bussine->nombre); ?></a>
							</td>
							<td class="text-center"><?php echo e($bussine->tarjeta); ?>%</td>
							<td class="text-center">
								<span class="label label-success">
									<?php echo e($bussine->estatus); ?>

								</span>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>