<?php $__env->startSection('title','Agrega nuevo traspaso'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="header">
				<h4 class="title">Detalle de traspaso</h4>  <hr style="margin-bottom:4px !important;">
			</div>
			<div class="content" style="margin:0px;"> 
				Sucursal que recibe: <?php echo e($traspaso->suc_recibe); ?> <hr style="margin-bottom:4px !important; margin-top:4px !important;">
				Fecha: <?php echo e($traspaso->fecha); ?> <hr style="margin-bottom:4px !important; margin-top:4px !important;">
				Usuario: <?php echo e($traspaso->usuario); ?>

			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-8">
		<div class="card">
			<div class="header">
				<h4 class="title">Selecciona los productos que vas a traspasar</h4>
			</div>
			<div class="content table-responsive table-full-width">
				<div class="row">
					<div class="col-md-10 col-lg-10 col-sm-12">
						<form action="<?php echo e(asset('dashboard/traspaso/buscar/producto/')); ?>" method="get">
							
							<input style="margin: 10px;" placeholder="Buscar Producto" type="search" class="form-control" name="filtro">
							<input type="hidden" value="<?php echo e($traspaso->id); ?>" name="traspaso">
						</form>
						
					</div>
				</div>
				<hr>
				<div class="content table-responsive table-full-width">
					<table class="table table-striped">
						<thead>
							<th class="text-center">ID</th>
							<th class="text-center">Producto</th>
							<th class="text-center">Costo</th>
							<th class="text-center">Venta</th>
							<th class="text-center">Cantidad</th>
							<th class="text-center">Acciones</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<form action="<?php echo e(asset('dashboard/agregar-producto-traspaso')); ?>" method="post">
								<?php echo csrf_field(); ?>
								<input type="hidden" value="<?php echo e($product->id); ?>" name="producto_id">
								<input type="hidden" value="<?php echo e($traspaso->id); ?>" name="traspaso_id">
								<tr>
									<td class="text-center"><?php echo e($product->id); ?></td>
									<td class="text-center"><?php echo e($product->producto); ?> - <?php echo e($product->stock); ?></td>
									<td class="text-center">$<?php echo e($product->costo); ?></td>
									<td class="text-center">$<?php echo e($product->venta); ?></td>
									<td class="text-center">
										<input class="form-control" type="number" required="" max="<?php echo e($product->stock); ?>" name="cantidad" placeholder="Cantidad a traspasar">
									</td>
									<td class="text-center">
										<button type="submit" class="btn btn-success">Agregar</button>
									</td>
								</tr>
							</form>
							
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
					<div class="content">
						<?php echo e($products->links()); ?>

					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-4">
		<div class="card">
			<div class="header">
				<h4 class="title">Productos a traspasar</h4>
			</div>
			<div class="content">
				<?php if(count($products_traspasos) != 0): ?>
					<form action="<?php echo e(asset('dashboard/traspaso/terminar')); ?>" method="post" class="text-center">
						<?php echo csrf_field(); ?>
						<input type="hidden" value="<?php echo e($traspaso->id); ?>" name="traspaso_id">
						<button type="submit" class="btn btn-success ">Terminar Traspaso</button>
					</form> <hr>
				<?php else: ?>
					<h4 class="titel text-center">Sin productos agregados</h4>
				<?php endif; ?>
				<div class="row">
					<div class="col-sm-12">
						<?php $__currentLoopData = $products_traspasos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<ul class="list-group">
								<li class="list-group-item"><?php echo e($product->producto); ?> - 
									<span class="label label-success">
										<?php echo e($product->cantidad); ?> a traspasar
									</span>
								</li>
							</ul>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>