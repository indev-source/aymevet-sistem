<table id="data" class="table table-striped">
    <thead>
        <th class="text-center">Nombre</th>
        <th class="text-center">Email</th>
        <th class="text-center">Ruta</th>
        <th class="text-center">Rol</th>
        <th class="text-center">Acciones</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center">
                    <?php echo e($user->name); ?>

                </td>
                <td class="text-center"><?php echo e($user->email); ?></td>
                <td class="text-center text-uppercase"><?php echo e($user->business->nombre); ?></td>
                <td class="text-center text-uppercase"><?php echo e($user->rol); ?></td>
                <td class="text-center ">
                    <a href="<?php echo e(asset('perfil?empleado='.$user->id)); ?>" class="btn btn-primary"><span class="fa fa-user"></span> Pefil</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>