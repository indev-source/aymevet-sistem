<?php $__env->startSection('title','Traspasos'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
		<div class="header flex">
			<h4 class="title text-uppercase">Listado de traspasos | <a href="/administrador/traspasos/create">Agregar nuevo</a></h4>
			<form action="<?php echo e(asset('traspasos')); ?>" class="flex padding-form">
				<select name="estatus" class="form-control margin-right-sml" id="">
					<option value="">Selecciona un estatus</option>
					<option value="autorizado">Autorizados</option>
					<option value="aceptado">Aceptados</option>
					<option value="enviado">Enviados</option>
					<option value="proceso">En proceso</option>
				</select>
				<button class="btn btn-primary">Filtrar</button>
			</form>
		</div> <hr>
		<div class="content table-responsive ">
			<?php echo $__env->make('traspasos.data', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>