<?php $__env->startSection('title','Clientes'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
	<?php if(session('status_success')): ?>
        <div class="alert alert-success">
            <?php echo session('status_success'); ?>

        </div>
    <?php endif; ?>
	<div class="card">
		<div class="header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap;">
			<h4 class="title">
                <?php if($operacion == 0): ?>
                    Agregar un cliente nuevo
                <?php else: ?>
                    Actualizar Cliente
                <?php endif; ?>
            </h4>
		</div>
		<div class="content">
            <form action="<?php echo e(asset(Auth::user()->rol.'/'.$url)); ?>" method="post">
                <?php echo csrf_field(); ?> 
                <?php if($operacion == 1): ?>
                    <?php echo e(method_field('put')); ?>

                <?php endif; ?>
                <div class="form-group">
                    <label for="">Nombre completo</label>
                    <input type="text" value="<?php echo e($cliente->nombre_completo); ?>" class="form-control" name="nombre_completo" placeholder="">
                </div>
                <div class="form-group">
                    <label for="">Email</label>
                    <input type="email" value="<?php echo e($cliente->email); ?>" name="email" class="form-control" placeholder="">
                </div>
                <div class="form-group">
                    <label for="">Telefono</label>
                    <input type="text" name="telefono" value="<?php echo e($cliente->telefono); ?>" class="form-control" placeholder="">
                </div>
                <div class="form-group">
                    <label for="">Credito autorizado</label>
                    <input type="text" name="credito_autorizado" value="<?php echo e($cliente->credito_autorizado); ?>" class="form-control" placeholder="">
                </div>
                <div class="form-group">
                    <label for="">Direccion</label>
                    <textarea name="direccion" class="form-control" id="" cols="30" rows="10">
                        <?php echo e($cliente->direccion); ?>

                    </textarea>
                </div>
                <div class="form-group">
                    <label for="">Vendedor</label>
                    <select name="vendedor_id" class="form-control" id="">
                        <?php $__currentLoopData = $vendedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($vendedor->id); ?>"><?php echo e($vendedor->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <button class="btn btn-success" type="submit">
                        <?php if($operacion == 0): ?>
                            Agregar nuevo cliente
                        <?php else: ?>
                            Actualizar Cliente
                        <?php endif; ?>
                    </button>
                </div>
            </form>
        </div>
	</div>
</div>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>