<?php $__env->startSection('title','Empleados'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <?php if(session('status_success')): ?>
            <div class="alert alert-success">
                <?php echo session('status_success'); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <div class="header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap;">
                <h4 class="title">Vendedor: <?php echo e($seller->name); ?>, ventas del año: <?php echo e($year); ?></h4>
            </div>
            <div class="content table-responsive">
                <form action="<?php echo e(asset('reportes/ventas/vendedores/'.$seller->id)); ?>" method="get">
                    <div class="form-group">
                        <label for="date">Año: </label>
                        <input type="number" name="year" class="form-control" placeholder="Ingresa el año">
                    </div>
                </form>
                <ul class="list-group">
                    <?php $total = 0; ?>
                    <li class="list-group-item">
                        Enero:
                        <?php $__currentLoopData = $totalSellerByMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($mes->mes == 1): ?>
                               <?php $total += $mes->total_ventas; ?>
                                <span style="color:green; font-weight: bold;"> $<?php echo e(number_format($mes->total_ventas,2,'.',',')); ?></span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </li>
                    <li class="list-group-item">
                        Febrero:
                        <?php $__currentLoopData = $totalSellerByMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($mes->mes == 2): ?>
                                <?php $total += $mes->total_ventas; ?>
                                <span style="color:green; font-weight: bold;"> $<?php echo e(number_format($mes->total_ventas,2,'.',',')); ?></span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </li>
                    <li class="list-group-item">
                        Marzo:
                        <?php $__currentLoopData = $totalSellerByMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($mes->mes == 3): ?>
                                <?php $total += $mes->total_ventas; ?>
                                <span style="color:green; font-weight: bold;"> $<?php echo e(number_format($mes->total_ventas,2,'.',',')); ?></span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </li>
                    <li class="list-group-item">
                        Abril:
                        <?php $__currentLoopData = $totalSellerByMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($mes->mes == 4): ?>
                                <?php $total += $mes->total_ventas; ?>
                                <span style="color:green; font-weight: bold;"> $<?php echo e(number_format($mes->total_ventas,2,'.',',')); ?></span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </li>
                    <li class="list-group-item">
                        Mayo:
                        <?php $__currentLoopData = $totalSellerByMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($mes->mes == 5): ?>
                                <?php $total += $mes->total_ventas; ?>
                                <span style="color:green; font-weight: bold;"> $<?php echo e(number_format($mes->total_ventas,2,'.',',')); ?></span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </li>
                    <li class="list-group-item">
                        Junio:
                        <?php $__currentLoopData = $totalSellerByMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($mes->mes == 6): ?>
                                <?php $total += $mes->total_ventas; ?>
                                <span style="color:green; font-weight: bold;"> $<?php echo e(number_format($mes->total_ventas,2,'.',',')); ?></span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </li>
                    <li class="list-group-item">
                        Julio:
                        <?php $__currentLoopData = $totalSellerByMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($mes->mes == 7): ?>
                                <?php $total += $mes->total_ventas; ?>
                                <span style="color:green; font-weight: bold;"> $<?php echo e(number_format($mes->total_ventas,2,'.',',')); ?></span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </li>
                    <li class="list-group-item">
                        Agosto:
                        <?php $__currentLoopData = $totalSellerByMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($mes->mes == 8): ?>
                                <?php $total += $mes->total_ventas; ?>
                                <span style="color:green; font-weight: bold;"> $<?php echo e(number_format($mes->total_ventas,2,'.',',')); ?></span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </li>
                    <li class="list-group-item">
                        Septiembre:
                        <?php $__currentLoopData = $totalSellerByMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($mes->mes == 9): ?>
                                <?php $total += $mes->total_ventas; ?>
                                <span style="color:green; font-weight: bold;"> $<?php echo e(number_format($mes->total_ventas,2,'.',',')); ?></span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </li>
                    <li class="list-group-item">
                        Octubre:
                        <?php $__currentLoopData = $totalSellerByMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($mes->mes == 10): ?>
                                <?php $total += $mes->total_ventas; ?>
                                <span style="color:green; font-weight: bold;"> $<?php echo e(number_format($mes->total_ventas,2,'.',',')); ?></span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </li>
                    <li class="list-group-item">
                        Noviembre:
                        <?php $__currentLoopData = $totalSellerByMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($mes->mes == 11): ?>
                                <?php $total += $mes->total_ventas; ?>
                                <span style="color:green; font-weight: bold;"> $<?php echo e(number_format($mes->total_ventas,2,'.',',')); ?></span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </li>
                    <li class="list-group-item">
                        Diciembre:
                        <?php $__currentLoopData = $totalSellerByMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($mes->mes == 12): ?>
                                <?php $total += $mes->total_ventas; ?>
                                <span style="color:green; font-weight: bold;"> $<?php echo e(number_format($mes->total_ventas,2,'.',',')); ?></span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </li>
                    <li class="list-group-item">
                        <span style="color:green; font-weight: bold;">Ventas totales en el año <?php echo e($year); ?>: $<?php echo e(number_format($total,2,'.',',')); ?></span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>