<?php if(count($services_traspaso) == 0): ?>
    <li>
        <a href="">No hay ningun traspaso disponible</a>
    </li>
<?php else: ?>
    <?php $__currentLoopData = $services_traspaso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $traspaso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(asset(Auth::user()->rol.'/traspasos/'.$traspaso->id)); ?>">
                <i class="ti-share"></i> <?php echo e($traspaso->nombre); ?>(<?php echo e($traspaso->productos); ?>)(<?php echo e($traspaso->fecha); ?>)
            </a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>