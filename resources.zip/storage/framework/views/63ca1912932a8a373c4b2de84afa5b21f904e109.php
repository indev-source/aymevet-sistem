
<?php $__env->startSection('title','Traspasos'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
	<a href="<?php echo e(asset('dashboard/seleccionar-sucursal')); ?>" class="float">
		<i class="fa fa-plus my-float"></i>
	</a>
	<?php if(session('status_success')): ?>
        <div class="alert alert-success">
            <?php echo session('status_success'); ?>

        </div>
    <?php endif; ?>
    <div class="card">
		<div class="header">
			<h4 class="title">Listado de todos los traspasos.</h4>
		</div>
		<div class="content table-responsive table-full-width">
			<?php echo $__env->make('traspasos.data', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>