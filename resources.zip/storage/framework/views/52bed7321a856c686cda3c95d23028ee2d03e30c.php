<table  id="data" class="table table-striped table-bordered">
	<thead>
		<th class="text-center">Nombre</th>
		<th class="text-center">Email</th>
		<th class="text-center">Telefono</th>
		<th class="text-center">Direccion</th>
		<th class="text-center">Credito Autorizado</th>
	</thead>
	<tbody>
		<?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td class="text-center">
                    <a href="<?php echo e(asset(Auth::user()->rol.'/clientes/'.$cliente->id.'/edit')); ?>">
                        <?php echo e($cliente->nombre_completo); ?>

                    </a>
                </td>
				<td class="text-center"><?php echo e($cliente->email); ?></td>
				<td class="text-center"><?php echo e($cliente->telefono); ?></td>
                <td class="text-center"><?php echo e($cliente->direccion); ?></td>
                <td class="text-center">$<?php echo e(number_format($cliente->credito_autorizado,2,'.',',')); ?></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<div class="content">
	
</div>