<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="header">
			<h4 class="title">Selecciona la sucursal a traspasar</h4> <hr>
		</div>
		<div class="content">
			<div class="row">
				<?php $__currentLoopData = $bussines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bussine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<form action="<?php echo e(asset('dashboard/v/admin/traspasos')); ?>" method="post">
						<?php echo csrf_field(); ?>
						<input type="hidden" name="bussine_id" value="<?php echo e($bussine->id); ?>">
						<div class="col-md-8" style="margin-left: 25px;">
							<ul class="list-group" style="display: flex; align-items: center; justify-content: space-between;">
								<li class="list-group-item" style="width: 70%;"><?php echo e($bussine->nombre); ?></li>
								<button type="submit" class="btn btn-success btn-sm">Seleccionar</button>
							</ul>
							<hr>
						</div>
					</form>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php echo e($bussines->links()); ?>

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>