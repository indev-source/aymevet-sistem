<table class="table table-striped">
	<thead>
		<th class="text-center">ID</th>
		<th class="text-center">Sucursal envia</th>
		<th class="text-center">Sucursla Recibe</th>
		<th class="text-center">Usuario envia</th>
		<th class="text-center">Fecha</th>
		<th class="text-center">Estatus</th>
	</thead>
	<tbody>
		<?php $__currentLoopData = $traspasos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $traspaso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td class="text-center">
					<?php if($traspaso->estatus == 'enviado'): ?>
						<a href="<?php echo e(asset('dashboard/v/admin/traspasos/'.$traspaso->id)); ?>"><?php echo e($traspaso->id); ?></a>
					<?php elseif($traspaso->estatus == 'proceso' and $traspaso->envia == Auth::user()->bussine_id): ?>
						<a href="<?php echo e(asset('dashboard/seleccionar-productos/'.$traspaso->id)); ?>"><?php echo e($traspaso->id); ?></a>
					<?php else: ?>
						<a href="<?php echo e(asset('dashboard/v/admin/traspasos/'.$traspaso->id)); ?>"><?php echo e($traspaso->id); ?></a>
					<?php endif; ?>
				</td>
				<td class="text-center"><?php echo e($traspaso->suc_envia); ?></td>
				<td class="text-center"><?php echo e($traspaso->suc_recibe); ?></td>
				<td class="text-center"><?php echo e($traspaso->usuario); ?></td>
				<td class="text-center"><?php echo e($traspaso->fecha); ?></td>
				<td class="text-center"><?php echo e($traspaso->estatus); ?></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<div class="content">
	<?php echo e($traspasos->links()); ?>

</div>