
<?php $__env->startSection('title','Clientes'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    Agregar credito
                </div>
                <div class="content">
                    <form action="<?php echo e(asset(Auth::user()->rol.'/creditos')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('credits.form',['btn'=>'Agregar Credito'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>