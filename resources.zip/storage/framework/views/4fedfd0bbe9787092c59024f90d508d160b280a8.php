<?php $__env->startSection('title','Empleados'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <?php if(session('status_success')): ?>
            <div class="alert alert-success">
                <?php echo session('status_success'); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <div class="header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap;">
                <h4 class="title">Listado de compras.</h4>
                <p class="category">
                    <a class="btn btn-success btn-sm" href="<?php echo e(asset('administrador/compras/create')); ?>">
                        Agregar compra
                    </a>
                </p>
            </div>
            <div class="content table-responsive">
                <table id="data" class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center">FOLIO</th>
                            <th class="text-center">Total</th>
                            <th class="text-center">Compra</th>
                            <th class="text-center">Fecha pago</th>
                            <th class="text-center">Dias para pagar</th>
                            <th class="text-center">Estus</th>
                            <th class="text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($compra->id); ?></td>
                                <td>$<?php echo e(number_format($compra->total,2,'.',',')); ?></td>
                                <td>
                                    <?php echo e($compra->tipo_compra); ?>

                                </td>
                                <td>
                                    <?php if($compra->estatus == 'pagado'): ?>
                                        <span class="<?php echo e($compra->estatus); ?>">pagada</span>
                                    <?php else: ?>
                                        <span class="<?php echo e($compra->estatus); ?>"><?php echo e($compra->fecha_pago); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($compra->estatus == 'pagado'): ?>
                                        <span class="<?php echo e($compra->estatus); ?>">pagada</span>
                                    <?php else: ?>
                                        <span class="<?php echo e($compra->estatus); ?>"><?php echo e($compra->dias_pago); ?> dia(s) restantes</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="<?php echo e($compra->estatus); ?>"><?php echo e($compra->estatus); ?></span>
                                </td>
                                <td>
                                    <a href="" class="btn btn-success btn-xs">Ver</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>