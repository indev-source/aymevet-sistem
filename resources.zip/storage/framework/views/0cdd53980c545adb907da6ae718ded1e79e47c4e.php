<form action="<?php echo e(asset('administrador/productos')); ?>" method="get">
	<div class="row">	
		<div class="col-md-3">
			<label for="">Buscar producto por categoria</label>
			<select class="form-control" name="categoria" id="">
				<option selected="" value="0">Todas las categorias</option>
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option  value="<?php echo e($category->id); ?>"><?php echo e($category->nombre); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
		<div class="col-md-3">
			<label for="">Buscar producto por marca</label>
			<select class="form-control" name="categoria" id="">
				<option selected=""  value="0">Todas las marcas</option>
				<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($brand->id); ?>"><?php echo e($brand->nombre); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
		<div class="col-md-3">
			<label for="">Buscar producto por proveedor</label>
			<select class="form-control" name="categoria" id="">
				<option selected="" value="0">Todas los proveedores</option>
				<?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $providers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option  value="<?php echo e($providers->id); ?>"><?php echo e($providers->nombre_completo); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
		<?php if(Auth::user()->rol == 'administrador'): ?>
		<div class="col-md-3">
			<label for="">Buscar productos por sucursal</label>
			<select class="form-control" name="bussine" id="">
				<option selected=""  value="0">Todas las sucursales</option>
				<?php $__currentLoopData = $bussines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bussine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($bussine->id); ?>"><?php echo e($bussine->nombre); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
		<?php endif; ?>
		<div class="col-md-12">
			<div class="form-group category">
				<button type="submit" class="btn btn-success">Filtar</button>
			</div>
		</div>
	</div>	
</form>
