<?php $__env->startSection('title','Categorias'); ?>
<?php $__env->startSection('content'); ?>
	
<div class="col-md-12">
	<?php if(session('status_success')): ?>
        <div class="alert alert-success">
            <?php echo session('status_success'); ?>

        </div>
    <?php endif; ?>
	<div class="card">
		<div class="header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap;">
			<h4 class="title">Listado de todas las categorias</h4>
			<p class="category">
				<a class="btn btn-success btn-sm" href="<?php echo e(asset(Auth::user()->rol.'/categorias/create')); ?>" >
					Agregar nueva categoria
				</a>
			</p>
		</div>
		<div class="content table-responsive ">
			<table id="data" class="table table-striped table-bordered">
				<thead>
					<th class="text-center">ID</th>
					<th class="text-center">Nombre</th>
					<th class="text-center">Num productos</th>
					<th class="text-center">Acciones</th>
				</thead>
				<tbody>
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td class="text-center"><?php echo e($category->id); ?></td>
							<td class="text-center">
								<a href="<?php echo e(asset('dashboard/v/admin/categorias/'.$category->id.'/edit')); ?>">
									<?php echo e($category->nombre); ?>

								</a>
							</td>
							<td class="text-center"><?php echo e($category->numero_productos); ?> Productos</td>
							<td class="text-center">
								<a href="<?php echo e(asset('dashboard/v/admin/categorias/'.$category->id)); ?>">Ver productos</a>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>