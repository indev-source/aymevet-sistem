<?php $__env->startSection('title','Detalle del credito'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
            <div class="row">
                <div class="col-md-8 col-lg-8 col-xs-12 col-xs-12">
                    <div class="card">
                        <div class="card-content">
                            <ul class="list-group">
                                <li class="list-group-item">
                                    <strong>Fecha del credito: </strong> <?php echo e($credit->created_at->format('Y-m-d')); ?> <br>
                                </li>
                                <li class="list-group-item">
                                    <strong>Estatus: </strong> <span class="label <?php echo e($credit->estatus == 'adeudo' ? 'label-danger' : 'label-success'); ?>">
                                        <?php echo e($credit->estatus); ?>

                                    </span>
                                </li>
                                <li class="list-group-item">
                                    <strong>Total: </strong> $<?php echo e(number_format($total,2,',','.')); ?> <br>
                                </li>
                                <li class="list-group-item">
                                    <strong>Vendedor: </strong> <?php echo e($sale->seller->name); ?> <br>
                                </li>
                                <li class="list-group-item">
                                    <strong>Ruta: </strong> <?php echo e($sale->business->nombre); ?> <br>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 col-xs-12 col-sm-12" style="height: 200px; overflow-y: scroll;">
                    <ul class="list-group" >
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <strong>Producto: </strong> <a href="<?php echo e(asset('')); ?>"><?php echo e($product->nombre); ?></a> <br>
                                <strong>Cantidad: </strong><?php echo e($product->cantidad); ?> <br>
                                <strong>Precio: </strong><?php echo e($product->precio); ?> <br>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 col-lg 8 col-xs-12 col-sm-12">
                    <?php if(session('status_success')): ?>
                        <div class="alert alert-success">
                            <?php echo session('status_success'); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('status_warning')): ?>
                        <div class="alert alert-warning">
                            <?php echo session('status_warning'); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="header">
                            <h5>Historial de pagos</h5>
                        </div>
                        <div class="content">
                            <div class="row">
                                <div class="col-md-8 col-lg-8 col-xs-12 col-sm-12">
                                    <ul class="list-group">
                                        <?php $__currentLoopData = $pays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item">
                                                <strong>Pago: </strong> $<?php echo e(number_format($pay->pago,2,',','.')); ?><br>
                                                <strong>Fecha: </strong><?php echo e($pay->created_at); ?>

                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <div class="col-md-4 col-xs-12 col-lg-4 col-sm-12">
                                    <ul class="list-group">
                                        <li class="list-group-item">
                                            <strong>Deuda total: </strong> <span style="color:indianred">$<?php echo e(number_format($total,2,',','.')); ?></span>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>Pagado: </strong> <span style="color:seagreen;">$<?php echo e(number_format($payed,2,',','.')); ?></span>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>Restante: </strong> <span style="color: brown;">$<?php echo e(number_format($toPay,2,',','.')); ?></span>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
               <div class="col-md-4 col-xs-12 col-lg-4 col-sm-12">
                   <div class="card">
                       <div class="header">
                           <h5 class="">Recibir pago</h5>
                       </div>
                       <div class="content">
                           <form action="<?php echo e(asset('pagos')); ?>" method="post">
                               <?php echo csrf_field(); ?>
                               <input type="hidden" name="venta" value="<?php echo e($sale->id); ?>">
                               <input type="hidden" name="credito" value="<?php echo e($credit->id); ?>">
                               <input type="hidden" name="cliente" value="<?php echo e($sale->cliente); ?>">
                               <div class="form-group">
                                   <input  <?php if($credit->estatus == 'pagado'): ?> disabled <?php endif; ?> type="number" step="any" min="1" class="form-control" name="pago" placeholder="Ingresa la cantidad">
                               </div>
                               <button <?php if($credit->estatus == 'pagado'): ?> disabled <?php endif; ?> type="submit" class="btn btn-success form-control">Agregar</button>
                           </form>
                       </div>
                   </div>
               </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>