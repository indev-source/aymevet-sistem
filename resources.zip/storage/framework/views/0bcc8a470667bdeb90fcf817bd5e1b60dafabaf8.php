<?php $__env->startSection('title','Ventas'); ?>
<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="header">
					<h5 class="card-title"><?php echo e($msg); ?></h5>
				</div>
				<div class="content">
					<?php echo $__env->make('sales.data', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>