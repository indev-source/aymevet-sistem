<li>
	<a href="">Traspasos por autorizar</a>
</li>
<li class="divider"></li>
<?php $__currentLoopData = $services_traspaso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $traspaso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li><a href="<?php echo e(asset(Auth::user()->rol.'/traspasos/'.$traspaso->id)); ?>"><?php echo e($traspaso->nombre); ?>(<?php echo e($traspaso->fecha); ?>)</a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>