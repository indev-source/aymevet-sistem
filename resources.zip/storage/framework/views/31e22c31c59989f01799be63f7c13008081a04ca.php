<table  id="data" class="table table-striped table-bordered">
	<thead>
		<th class="text-center">Nombre</th>
		<th class="text-center">Estatus</th>
	</thead>
	<tbody>
		<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td class="text-center">
                    <a href="<?php echo e(asset(Auth::user()->rol.'/marcas/'.$brand->id.'/edit')); ?>">
                        <?php echo e($brand->nombre); ?>

                    </a>
                </td>
				<td class="text-center">
                    <?php if($brand->estatus == 0): ?>
                        <span class="label label-success">Activo</span>  
                    <?php endif; ?>
                </td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<div class="content">
	
</div>