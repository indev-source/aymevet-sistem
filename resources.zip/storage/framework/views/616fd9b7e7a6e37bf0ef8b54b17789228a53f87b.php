<?php $__env->startSection('title','Empleados'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
	
	<?php if(session('status_success')): ?>
        <div class="alert alert-success">
            <?php echo session('status_success'); ?>

        </div>
    <?php endif; ?>
	<div class="card">
		<div class="header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap;">
			<h4 class="title">Listado de usuario activos.</h4>
			<p class="category">
				<a class="btn btn-success btn-sm" href="<?php echo e(asset('dashboard/v/admin/usuarios/create')); ?>">
					Agregar usuario
				</a>
			</p>
		</div>
		<div class="content table-responsive">
			<table id="data" class="table table-striped">
				<thead>
					<th class="text-center">Nombre</th>
					<th class="text-center">Email</th>
					<th class="text-center">Estatus</th>
					<th class="text-center">Sucursal</th>
					<th class="text-center">Rol</th>
				</thead>
				<tbody>
					<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td class="text-center">
								<a href="<?php echo e(asset('/dashboard/v/admin/perfil?id='.$user->id)); ?>"><?php echo e($user->name); ?></a>
							</td>
							<td class="text-center"><?php echo e($user->email); ?></td>
							<td class="text-center">
								<span class="label label-success">
									<?php echo e($user->status); ?>

								</span>
							</td>
							<td class="text-center"><?php echo e($user->bussine->nombre); ?></td>
							<td class="text-center"><?php echo e($user->rol); ?></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>