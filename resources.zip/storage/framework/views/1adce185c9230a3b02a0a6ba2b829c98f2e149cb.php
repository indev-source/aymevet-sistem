<?php $__env->startSection('title',Auth::user()->name); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-5 col-lg-4 col-sm-12 col-xs-12">
		<div class="card card-user">
			<div class="image">
				<img src="<?php echo e(asset('banner-profile.jpg')); ?>" alt="..."/>
			</div>
			<div class="content">
				<div class="author">
					<img class="avatar border-white" src="<?php echo e(asset('default.png')); ?>" alt="..."/>
					<h4 class="title text-uppercase"><?php echo e($user->name); ?></h4>
				</div>
			</div>
			<div class="content">
				<div class="row">
					<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
						<div class="card">
							<div class="card-title"><h5 class="title text-uppercase text-center">Ventas</h5></div>
							<div class="content">
								<img src="<?php echo e(asset('sale.png')); ?>" class="img-width-total cursor-pointer" alt="">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-7 col-lg-7 col-sm-12 col-xs-12">
		<?php echo $__env->make('alerts.alert-success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="card">
			<div class="header">
				<h4 class="title text-uppercase">actualizar datos</h4>
			</div>
			<div class="content">
				<div class="row">
					<form action="<?php echo e(asset('administrador/usuarios/'.$user->id)); ?>" method="post" class="padding-form">
						<?php echo csrf_field(); ?>
						<?php echo e(method_field('put')); ?>

						<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
							<div class="form-group">
								<label for="">Nombre del empleado</label>
								<input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>">
							</div>
						</div>
						<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
							<div class="form-group">
								<label for="">Celular del empleado</label>
								<input type="text" class="form-control" name="celular" value="<?php echo e($user->celular); ?>">
							</div>
						</div>
						<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
							<div class="form-group">
								<label for="">Correo electronico del empleado</label>
								<input type="text" class="form-control" name="email" value="<?php echo e($user->email); ?>">
							</div>
						</div>
						<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
							<div class="form-group">
								<label for="">Rol: <span class="color-primary text-uppercase"><?php echo e($user->rol); ?></span></label>
								<a href="" class="btn btn-primary form-control">Volverlo administrador</a>
							</div>
						</div>
						<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
							<div class="form-group">
								<label for="">Ruta del vendedor</label>
								<select name="bussine_id" id="" class="form-control">
									<option value="<?php echo e($user->business->id); ?>"><?php echo e($user->business->nombre); ?></option>
									<?php $__currentLoopData = $bussines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($bs->id); ?>"><?php echo e($bs->nombre); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
						
						<button class="btn btn-primary"><span class="fa fa-edit"></span> Actualizar datos</button>
					</form>
				</div>
				<hr>
				<div class="row">
					<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
						<form action="<?php echo e(asset('administrador/usuarios/password-update/'.$user->id)); ?>" method="POST">
							<?php echo csrf_field(); ?>
							<?php echo e(method_field('put')); ?>

							<div class="form-group">
								<label for="">Actualizar contraseña</label>
								<input type="password" class="form-control" name="password" required>
							</div>
							<button class="btn btn-primary"><span class="fa fa-lock"></span> Actualizar</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>