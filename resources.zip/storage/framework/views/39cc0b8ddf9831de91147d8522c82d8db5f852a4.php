<table id="data" class="table">
	<thead>
		<th class="text-center">Sucursal envia</th>
		<th class="text-center">Sucursla Recibe</th>
		<th class="text-center">Usuario envia</th>
		<th class="text-center">Fecha</th>
		<th class="text-center">Estatus</th>
		<th class="text-center">Detalle</th>
	</thead>
	<tbody>
		<?php $__currentLoopData = $traspasos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $traspaso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td class="text-center"><?php echo e($traspaso->senvia->nombre); ?></td>
				<td class="text-center"><?php echo e($traspaso->srecibe->nombre); ?></td>
				<td class="text-center"><?php echo e($traspaso->usuario->name); ?></td>
				<td class="text-center"><?php echo e($traspaso->created_at); ?></td>
				<td class="text-center"><?php echo e($traspaso->estatus); ?></td>
				<td class="text-center">
					<a href="<?php echo e(asset('/administrador/traspasos/'.$traspaso->id)); ?>" class="btn btn-success btn-sm">Detalle</a>
				</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<div class="content">

</div>
