<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="header">
			<h4 class="title">Selecciona una ruta para traspasar</h4> <hr>
		</div>
		<div class="content" style="padding: 20px;">
			<div class="row">
				<?php $__currentLoopData = $bussines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bussine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="<?php echo e(asset('dashboard/v/admin/traspasos')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="bussine_id" value="<?php echo e($bussine->id); ?>">
                        <div class="col-md-3">
                            <div class="card text-center">
                                <div class="header">
                                    <h5 class="title">
                                        Ruta: <?php echo e($bussine->nombre); ?>

                                    </h5>
                                </div>
                                <div class="content">
                                    <img style="width: 100%;" src="https://image.flaticon.com/icons/svg/31/31520.svg" alt="">
                                </div>
                                <button style="margin-bottom: 10px;" type="submit" class="btn btn-success">Seleccionar</button>
                            </div>
                        </div>
                    </form>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php echo e($bussines->links()); ?>

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>