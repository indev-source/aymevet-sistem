<?php $__env->startSection('title','Traspasos'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <?php if(session('status_success')): ?>
            <div class="alert alert-success">
                <?php echo session('status_success'); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <div class="header">
                <h4 class="title">Listado de traspasos autorizados.</h4>
            </div>
            <div class="content table-responsive ">
                <?php echo $__env->make('traspasos.data.autorizados', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>