<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
    <style>
        * {
            font-size: 12px;
            font-family: 'Times New Roman';
        }
        td,th,tr,table {
            border-top: 1px solid black;
            border-collapse: collapse;
        }
        td.producto,th.producto {
            width: 150px;
            max-width: 150px;
        }
        td.cantidad,th.cantidad {
            width: 40px;
            max-width: 40px;
            word-break: break-all;
        }
        td.precio,th.precio {
            width: 40px;
            max-width: 40px;
            word-break: break-all;
        }
        .centrado {
            text-align: center;
            align-content: center;
            width: 100%;
        }
        .ticket {
            width: 155px;
            max-width: 155px;
        }
        img {
            max-width: inherit;
            width: inherit;
        }
        @media  print{
          .oculto-impresion, .oculto-impresion *{
            display: none !important;
          }
        }
    </style>
</head>
<body>
<div class="ticket">
    <img src="http://www.gruposalinas.com/images/nv/Italika.png" alt="Logotipo">
    <p class="centrado">
        Sucursal <?php echo e($bussine->nombre); ?> <br> 
        Calle <?php echo e($bussine->calle); ?> numero <?php echo e($bussine->numero_exterior); ?>,Colonia <?php echo e($bussine->colonia); ?>, <br>
        Atendido por: <?php echo e($user->name); ?>, Venta:<?php echo e($sale->status); ?> <br>
        Fecha: <?php echo e($sale->created_at); ?> <br>
        Folio: <?php echo e($sale->id); ?>

    </p>
    <section id="ticket" style="display: flex; justify-content: space-between; align-items: center;">
        <div id="pro-th">CANT</div>
        <div id="pre-th">PRO  <br></div>   
        <div id="cod-th">P/U</div>
        <div id="subtotal">IMP</div>
    </section>
    <hr>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="display: flex; align-items: center; justify-content: space-between;">
            <div id="pro-td">
                <?php echo e($product->cantidad); ?> 
            </div>
            <div id="pre-td" style="text-align: center;"><?php echo e($product->producto); ?> </div>
            <div id="can-td" style="text-align: center; margin-right:3px !important;">$<?php echo e($product->precio); ?> </div>
            <div id="subtotal" style="text-align: center;">$<?php echo e($product->subtotal); ?> </div>
        </div>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div id="total"> <br>
        Pago con tarjeta : $0.00 <br>
        Descuento: $0.00 <br>
        ============ <br>
        Subtotal: $<?php echo e(number_format($total,2,'.',',')); ?>  
        ============ <br>
        Total: $<?php echo e(number_format($subtotal,2,'.',',')); ?> <br>
        ============ <br>
    </div>
    <p class="centrado">RFC: CAC130624MY3</p>
    <p class="centrado">Email: motocrea@hotmail.com</p>
    <p class="centrado">¡GRACIAS POR SU COMPRA!</p>
    <p class="centrado">Este ticket no es comprobante fiscal y se incluirá en la venta del día</p>
</div>
<a href="<?php echo e(asset('dashboard/vender')); ?>" class="oculto-impresion">Regresar</a>
</body>
<script>
    window.print();
    window.addEventListener("afterprint", function(event) {
       location.href ="http://www.ital2201.com/dashboard/vender";
    });
</script>
</html>