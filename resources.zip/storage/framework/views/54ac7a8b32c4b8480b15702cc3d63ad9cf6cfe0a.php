<table  id="data" class="table table-striped table-bordered">
	<thead>
		<th class="text-center">Nombre</th>
		<th class="text-center">Telefoni</th>
		<th class="text-center">Vendedor</th>
		<th class="text-center">Estatus</th>
        <th class="text-center">Acciones</th>
	</thead>
	<tbody>
		<?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td class="text-center"><?php echo e($cliente->nombre_completo); ?></td>
				<td class="text-center"><?php echo e($cliente->telefono); ?></td>
				<td class="text-center"><?php echo e($cliente->seller->name); ?></td>
				<td class="text-center"><?php echo e($cliente->estatus); ?></td>
                <td class="text-center">

                    <a href="<?php echo e(asset('clientes/'.$cliente->id.'/edit')); ?>" class="btn btn-info btn-sm"><span class="fa fa-edit"></span> Actualizar</a>
                    <a href="<?php echo e(asset('ventas-cliente?cliente='.$cliente->id)); ?>" class="btn btn-info btn-sm"><span class="fa fa-balance-scale"></span> Ver compras</a>
                </td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<div class="content">

</div>
