<?php $__env->startSection('title','Clientes'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap;">
        <h4 class="title">Listado de clientes.</h4>
        <p class="category">
            <a class="btn btn-success btn-sm" href="<?php echo e(asset(Auth::user()->rol.'/creditos/create')); ?>">Agregar credito</a>
        </p>
    </div>
    <div class="content table-responsive ">
        <?php echo $__env->make('credits.data', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>