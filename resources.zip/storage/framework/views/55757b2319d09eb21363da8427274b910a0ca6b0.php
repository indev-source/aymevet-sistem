<div class="card">
	<div class="header">
		<h3 class="title">
			Folio de venta: <?php echo e($sale->id); ?>, Tota: $<?php echo e($sale->total); ?>

			<a href="<?php echo e(asset('dashboard/venta?ticket='.$sale->id)); ?>" class="btn btn-xs btn-success">Reimprimir ticket</a>
			<?php if(Auth::user()->rol == 'administrador' and $sale->status != 'cancelado'): ?>
				<form action="<?php echo e(asset('dashboard/v/admin/ventas/'.$sale->id)); ?>" method="post" style="display: inline-block;">
					<?php echo csrf_field(); ?>
					<?php echo e(method_field('delete')); ?>

					<button type="submit" class="btn btn-xs btn-danger">Cancelar venta</button>
				</form>
			<?php endif; ?>
			<?php if($sale->status == 'cancelado'): ?>
				<span class="label label-danger">Venta canceladas, los productos fuerón regresados al inventario</span>
			<?php endif; ?>
		</h3>
	</div>
	<div class="content table-responsive">
		<table id="data" class="table table-striped table-bordered">
			<thead>
				<tr>
					<th class="text-center">Producto</th>
					<th class="text-center">Codigo</th>
					<th class="text-center">Cantidad</th>
					<th class="text-center">Precio</th>
					<th class="text-center">Subtotal</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td class="text-center"><?php echo e($product->nombre); ?></td>
					<td class="text-center"><?php echo e($product->codigo); ?></td>
					<td class="text-center"><?php echo e($product->cantidad); ?></td>
					<td class="text-center">$<?php echo e(number_format($product->precio,2,'.',',')); ?></td>
					<td class="text-center">$<?php echo e(number_format($product->subtotal,2,'.',',')); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
</div>
