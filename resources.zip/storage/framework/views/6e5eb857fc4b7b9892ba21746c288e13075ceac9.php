
<?php $__env->startSection('title','Ventas'); ?>
<?php $__env->startSection('content'); ?>
	<div class="row">
        <div class="col-lg-4 col-sm-6">
            <div class="card">
                <div class="content">
                    <div class="row">
                        <div class="col-xs-5">
                            <div class="icon-big icon-warning text-center">
                                <i class="ti-money"></i>
                            </div>
                        </div>
                        <div class="col-xs-7">
                            <div class="numbers">
                                <p style="color:black;">Total: $<?php echo e($information->totalMonthSale()); ?></p>
                                <p style="color:red;">Invertido: $20.00</p>
                                <p style="color:green;"> Ganancia: $100.00</p>
                            </div>
                        </div>
                    </div>
                    <div class="footer">
                        <hr />
                        <div class="stats">
                            <i class="ti-money"></i> Ventas del mes - <a href="">Obtener grafica</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6">
            <div class="card">
                <div class="content">
                    <div class="row">
                        <div class="col-xs-5">
                            <div class="icon-big icon-warning text-center">
                                <i class="ti-money"></i>
                            </div>
                        </div>
                        <div class="col-xs-7">
                            <div class="numbers">
                                <p style="color:black;">Total: $<?php echo e($information->totalDaySale()); ?></p>
                                <p style="color:red;">Invertido: $20.00</p>
                                <p style="color:green;"> Ganancia: $100.00</p>
                            </div>
                        </div>
                    </div>
                    <div class="footer">
                        <hr />
                        <div class="stats">
                            <i class="ti-money"></i> Ventas del dia - <a href="">Obtener grafica</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6">
            <div class="card">
                <div class="content">
                    <div class="row">
                        <div class="col-xs-5">
                            <div class="icon-big icon-warning text-center">
                                <i class="ti-money"></i>
                            </div>
                        </div>
                        <div class="col-xs-7">
                            <div class="numbers">
                                <p style="color:black;">Total: $<?php echo e($information->totalSales()); ?></p>
                                <p style="color:red;">Invertido: $20.00</p>
                                <p style="color:green;"> Ganancia: $100.00</p>
                            </div>
                        </div>
                    </div>
                    <div class="footer">
                        <hr />
                        <div class="stats">
                            <i class="ti-money"></i> Ventas totales - <a href="">Obtener grafica</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<div class="col-md-12">
			<div class="card">
				<div class="header">
					<h5 class="card-title">Ventas generales</h5>
				</div>
				<div class="content">
					<?php echo $__env->make('sales.data', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>