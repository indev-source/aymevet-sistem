@extends('layouts.dashboard.dashboard')
@section('content')
	<div class="col-md-12">
		@include('sales.data-products')
	</div>
@stop 